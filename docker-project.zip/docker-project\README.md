# Financial Goals Database - Docker Setup

This folder contains everything you need to run the financial goals database with Docker.

## Files Included

- **docker-compose.yml** — Docker Compose configuration for MySQL
- **.env** — Database credentials and configuration
- **init.sql** — Database schema and sample data
- **README.md** — This file

## Quick Start

### Prerequisites
- Docker installed on your machine
- Docker Compose installed

### Start the Database

```bash
docker compose up --pull always
```

This will:
- Pull the MySQL 8.0 image
- Create a container named `project_mysql`
- Initialize the database with your schema
- Create the `goals` and `transactions` tables

### Connect to the Database

In a new terminal:

```bash
docker exec -it project_mysql mysql -u developer -p project_db
```

When prompted, enter the password: `devpassword`

### Run SQL Queries

Once connected, you can query your tables:

```sql
-- View all goals
SELECT * FROM goals;

-- View all transactions
SELECT * FROM transactions;

-- Join transactions with goals
SELECT t.*, g.name as goal_name 
FROM transactions t 
JOIN goals g ON t.goal_id = g.id;
```

### Stop the Database

```bash
docker compose down
```

## Database Schema

### goals table
- `id` — Unique identifier (auto-increment)
- `name` — Goal name (e.g., "Wakacje", "Nowy laptop")
- `target_amount` — Target amount in decimal format
- `created_at` — Creation timestamp

### transactions table
- `id` — Unique identifier (auto-increment)
- `goal_id` — Foreign key linking to goals table
- `amount` — Transaction amount
- `description` — Transaction description
- `created_at` — Creation timestamp

## Sharing with Your Team

1. Commit all files to GitHub
2. Your teammates can clone the repository
3. They run `docker compose up --pull always`
4. Everyone has the same database setup

## Modifying the Schema or Data

Edit the `init.sql` file and restart Docker:

```bash
docker compose down
docker compose up --pull always
```

## Troubleshooting

If the container fails to start, check the logs:

```bash
docker compose logs mysql
```

For more help, see the [Docker documentation](https://docs.docker.com/compose/).
